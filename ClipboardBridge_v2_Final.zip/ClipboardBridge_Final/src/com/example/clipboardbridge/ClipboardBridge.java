package com.example.clipboardbridge;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;

@DesignerComponent(
        version = 2,
        description = "Clipboard helper for Kodular/App Inventor. Reads/writes clipboard and can dispatch a FloatingButtonClicked event from a floating button click handler.",
        category = com.google.appinventor.components.common.ComponentCategory.EXTENSION,
        nonVisible = true,
        iconName = "images/extension.png")
@SimpleObject(external = true)
public class ClipboardBridge extends AndroidNonvisibleComponent {

    private final Context context;
    private final ClipboardManager clipboard;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public ClipboardBridge(ComponentContainer container) {
        super(container.$form());
        context = container.$context();
        clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
    }

    @SimpleFunction(description = "Returns the current clipboard text. Returns empty text if unavailable.")
    public String GetClipboardText() {
        try {
            if (clipboard == null || !clipboard.hasPrimaryClip()) return "";
            ClipData data = clipboard.getPrimaryClip();
            if (data == null || data.getItemCount() == 0) return "";
            CharSequence text = data.getItemAt(0).coerceToText(context);
            return text == null ? "" : text.toString();
        } catch (Exception e) {
            return "";
        }
    }

    @SimpleFunction(description = "Copies text to the Android clipboard.")
    public void CopyText(String text) {
        final String value = text == null ? "" : text;
        try {
            if (clipboard != null) {
                clipboard.setPrimaryClip(ClipData.newPlainText("text", value));
            }
        } catch (Exception ignored) {
        }
    }

    @SimpleFunction(description = "Fires the FloatingButtonClicked event. Call this from the click event of your existing FloatingView button.")
    public void TriggerFloatingButtonClicked() {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                FloatingButtonClicked();
            }
        });
    }

    @SimpleEvent(description = "Fires when TriggerFloatingButtonClicked is called from a floating button click.")
    public void FloatingButtonClicked() {
        EventDispatcher.dispatchEvent(this, "FloatingButtonClicked");
    }

    @SimpleFunction(description = "Returns true when the clipboard currently has text.")
    public boolean HasClipboardText() {
        try {
            return clipboard != null && clipboard.hasPrimaryClip()
                    && clipboard.getPrimaryClip() != null
                    && clipboard.getPrimaryClip().getItemCount() > 0;
        } catch (Exception e) {
            return false;
        }
    }
}
