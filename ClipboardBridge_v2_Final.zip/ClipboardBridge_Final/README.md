# ClipboardBridge v2

এই extension-এর উদ্দেশ্য হলো আপনার existing FloatingView1 + Clock + TOTP extension-এর সাথে clipboard কাজ করা।

## Kodular blocks

### 1) Floating button click
```
when FloatingView1.ClickView
    call ClipboardBridge1.TriggerFloatingButtonClicked
```

### 2) FloatingButtonClicked
```
when ClipboardBridge1.FloatingButtonClicked
    call FloatingView1.RequestFocusFloatingView
    set Clock2.TimerEnabled to true
```

### 3) 100ms পরে clipboard পড়ুন
Clock2-এর TimerInterval = 100
```
when Clock2.Timer
    set Clock2.TimerEnabled to false
    set global Key to call ClipboardBridge1.GetClipboardText
    call TOTP1.GenerateAndFire global Key
```

### 4) OTP তৈরি হলে আবার clipboard-এ copy
```
when TOTP1.OTPGenerated otp
    call ClipboardBridge1.CopyText otp
    call Notifier1.ShowAlert otp
```

## গুরুত্বপূর্ণ
Android 10+ এ background clipboard access-এর সীমাবদ্ধতা আছে। `RequestFocusFloatingView` আপনার নির্দিষ্ট FloatingView implementation-এ clipboard read সফল করাতে পারে, কিন্তু এটি Android-এর সব ডিভাইসে guaranteed permission bypass নয়। আগে আপনার ডিভাইসে test করুন।

এই extension নিজে কোনো নতুন floating button বানায় না; আপনার existing FloatingView1-এর click থেকে TriggerFloatingButtonClicked ব্যবহার করে event তৈরি করা হয়।
